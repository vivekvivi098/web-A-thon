Free Bootstrap 5 Resume/CV Template for developers

Theme name:
=======================================================================
Pillar

Theme version:
=======================================================================
Bootstrap 5 v1.0

Release Date:
=======================================================================
2021-07-12

Author: 
=======================================================================
Xiaoying Riley at 3rd Wave Media (http://themes.3rdwavemedia.com/)

Contact:
=======================================================================
Web: http://themes.3rdwavemedia.com/
Email: themes@3rdwavemedia.com
Twitter: @3rdwave_themes

License: 
=======================================================================
This template is 100% FREE as long as you keep the footer attribution link. You do not have the rights to resell, sublicense or redistribute (even for free) the template on its own or as a separate attachment from any of your work.

